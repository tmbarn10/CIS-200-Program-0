﻿// Grading ID: C5503
// Program 0
// Due: 9/11/2017
// Course Section: CIS 200-01
// Description: Creates a console application that allows the testing of the letters and addresses.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<Address> address = new List<Address> // Creates a list named address based on the Address class
            {
                new Address("Larry Lobster", "3221 Bikini Bottom Way", "Louisville", "KY", 40216),
                new Address("John Cena", "4354 Attitude Avenue", "Room Number 2B", "Boulder", "CO", 58475),
                new Address("Jack Sparrow", "4563 Pirate Way", "Room Number 1A", "Frankfort", "KY", 40601),
                new Address("Travis Scott", "6954 Straight Up Road", "Houston", "TX", 77001)
            };

            List<Parcel> parcel = new List<Parcel> // Creates a list named parcel that adds parcels using origin and destination addressses and cost
            {
                new Letter(address[0], address[2], 1),
                new Letter(address[3], address[1], 4),
                new Letter(address[1], address[0], 6)
            };

            foreach (Letter letter in parcel) // Loop through each letter in current parcel and inputs to console
                Console.WriteLine("{0}\n", letter);
        }
    }
}
