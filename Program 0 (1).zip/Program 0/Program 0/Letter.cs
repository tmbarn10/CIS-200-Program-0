﻿// Grading ID: C5503
// Program 0
// Due: 9/11/2017
// Course Section: CIS 200-01
// Description: Gathers the originAddress and destinationAddress information from the Parcel class and uses that with the fixedCosts information to return a string of information that 
// holds the originAddress, destinationAddress, and calculated fixed costs.


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    class Letter: Parcel
    {
        private decimal fixedCosts;

        // Preconditions: None
        // Postconditions: The Letter constructor is initialized with data from originAddress, destinationAddress and fixed cost. Acquiring the originAddress and 
        // destinationAddress data from the Parcel class 
        public Letter(Address _originAddress, Address _destinationAddress, decimal _fixedCosts)
            : base(_originAddress, _destinationAddress)
        {
            FixedCosts = _fixedCosts;
        }

        // Preconditions: Value must be greater than zero, cannot be negative
        // Postconditions: fixedCosts value is returned and set to the FixedCosts property
        private decimal FixedCosts
        {
            get
            {
                return fixedCosts;
            }
            set
            {
                if (value < 0) // If fixedCosts value is not greater than or equal to 0, error will show up in console
                {
                    throw new ArgumentOutOfRangeException(nameof(value),
               value, $"{nameof(FixedCosts)} must be >= 0");
                }

                fixedCosts = value;
            }
        }
        
        public override decimal CalcCost() // Returns the fixed cost as a decimal
        {
            return fixedCosts;
        }

        public override string ToString() // A string is returned and formatted using the shipping information and cost gathered from the Letter constructor
        {   
            return string.Format("Origin Address: {3}{0}{3} Destination Address: {3}{1}{3}Costs:{2:C}{3}", OriginAddress, DestinationAddress, CalcCost(), System.Environment.NewLine);
        }
    }
}
