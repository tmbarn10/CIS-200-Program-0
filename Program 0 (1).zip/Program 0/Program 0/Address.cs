﻿// Grading ID: C5503
// Program 0
// Due: 9/11/2017
// Course Section: CIS 200-01
// Description: This class takes in information about the shipping of a package and validates and holds the values of all of the variables and 
// formats the values of the given information into a string.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public class Address
    {
        private string name; // Declaring a string variable for name
        private string addressLine1; // Declaring a string variable for addressLine1
        private string addressLine2; // Declaring a string variable for addressLine2
        private string city; // Declaring a string variable for city
        private string state; // Declaring a string variable for state
        private int zipCode; // Declaring an int variable for the zipCode
        private int zipMin = 0; // Declaring an int variable for the minimum zip code 0
        private int zipMax = 99999; // Declaring an int variable for maximum zip code 99999

        // Preconditions: None
        // Postconditions: The Address constructor now has values for the name, addressLine1, addressLine2, city, state, zipcode
        public Address(string _name, string _addressLine1, string _addressLine2, string _city, string _state, int _zipCode)
        {
            Name = _name;
            AddressLine1 = _addressLine1;
            AddressLine2 = _addressLine2;
            City = _city;
            State = _state;
            ZipCode = _zipCode;
        }
        // Preconditions: None
        // Postconditions: The Address constructor now has values for the name, addressLine1, city, state, zipcode. Overloaded constructor for when addressLine2 is left blank.
        public Address(string _name, string _addressLine1, string _city, string _state, int _zipCode)
        {
            Name = _name;
            AddressLine1 = _addressLine1;
            AddressLine2 = "";
            City = _city;
            State = _state;
            ZipCode = _zipCode;
        }

        // Preconditions: None
        // Postconditions: name value is returned and set to Name property
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        // Preconditions: None
        // Postconditions: addressLine1 is returned and set to AddressLine1 property
        public string AddressLine1
        {
            get
            {
                return addressLine1;
            }
            set
            {
                addressLine1 = value;
            }
        }

        // Preconditions: None
        // Postconditions: addressLine2 is returned and set to AddressLine2 property
        public string AddressLine2
        {
            get
            {
                return addressLine2;
            }
            set
            {
                addressLine2 = value;
            }
        }

        // Preconditions: None
        // Postconditions: city is returned and set to City property
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }
        // Preconditions: None
        // Postconditions: state is returned and set to State property
        public string State
        {
            get
            {
                return state;
            }
            set
            {
                state = value;
            }
        }
        // Preconditions: zipCode must be between 0 and 99999
        // Postconditions: zipCode is returned and set to ZipCode property if it falls between 0-99999
        public int ZipCode
        {
            get
            {
                return zipCode;
            }
            set
            {
                if ((zipCode >= zipMin) & (zipCode <= zipMax))
                    zipCode = value;
                    
            }
        }

        // Preconditions: None
        // Postconditions: A string is returned and formatted using the shipping information gathered in the Address constructor
        public override string ToString()
        {                 
            return string.Format("{0}{6}{1}{6}{2}{6}{3}, {4:D5} {5}{6}", Name, AddressLine1, AddressLine2, City, State, ZipCode, System.Environment.NewLine);
        }
    }
}
