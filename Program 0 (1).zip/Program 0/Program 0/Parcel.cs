﻿// Grading ID: C5503
// Program 0
// Due: 9/11/2017
// Course Section: CIS 200-01
// Description: Gathers information on the originAddress, destinationAddress, and CalcCost, and holds the information of each Parcel in a formatted string.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_0
{
    public abstract class Parcel
    {
        public Address originAddress; // Declares originAddress as an Address 
        public Address destinationAddress; // Declares destinationAddress as an Address

        // Preconditions: None
        // Postconditions: The Parcel constructor now has values for originAddress and destinationAddress
        public Parcel(Address _originAddress, Address _destinationAddress) // 
        {
            OriginAddress = _originAddress;
            DestinationAddress = _destinationAddress;           
        }

        // Preconditions: None
        // Postconditions: originAddress is returned and is set to the OriginAddress property
        public Address OriginAddress
        {
            get
            {
                return originAddress;
            }
            set
            {
                originAddress = value;
            }
        }

        // Preconditions: None
        // Postconditions: destinationAddress is returned and is set to the DestinationAddress property
        public Address DestinationAddress
        {
            get
            {
                return destinationAddress;
            }
            set
            {
                destinationAddress = value;
            }
        }

        public abstract decimal CalcCost(); // Returns the cost of the parcel as a decimal

        public override string ToString() // A string is returned and formatted using the originAddress, destinationAddress, and the cost
        {
            return string.Format("Origin Address:{3}{0}{3}Destination Address:{3}{1}{3}Cost:{2:C}{3}", OriginAddress, DestinationAddress, CalcCost(), System.Environment.NewLine);          
        }
    }
}
